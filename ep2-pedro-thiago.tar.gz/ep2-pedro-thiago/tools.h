#ifndef TOOLS_H
#define TOOLS_H

#include <stdlib.h>


int randInteger( int a, int b);
double randReal( double a, double b);
void trocaInt(int *a, int *b);

#endif
